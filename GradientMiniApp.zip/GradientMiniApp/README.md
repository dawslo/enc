# Encro Verse - Telegram Mini App

Gra kołem fortuny w Telegram Mini App z nagrodami w gwiazdkach.

## Funkcje

- 🎡 **Koło fortuny** z 8 kolorowymi segmentami (5-100 ⭐)
- ⭐ **System gwiazdek** z zapisem w localStorage
- 🎯 **Ważone prawdopodobieństwo** - niższe nagrody częstsze
- 💫 **Near-miss effect** - koło zatrzymuje się blisko dużych nagród
- 📱 **Telegram WebApp Integration** - haptic feedback, theme colors
- 💎 **System doładowań** - pakiety gwiazdek (50⭐, 150⭐, 500⭐)
- 🎨 **Gradient UI** z glassmorphism i neon efektami
- 🎉 **Konfetti** i celebracje przy wygranej

## Mechanika gry

- Koszt jednego obrotu: **10 ⭐**
- Początkowe saldo: **100 ⭐**
- Saldo zapisywane w localStorage

### Prawdopodobieństwa nagród

- 5 ⭐ - 40.0%
- 10 ⭐ - 30.0%
- 15 ⭐ - 15.0%
- 20 ⭐ - 8.0%
- 25 ⭐ - 4.0%
- 50 ⭐ - 2.0%
- 75 ⭐ - 0.8%
- 100 ⭐ - 0.2% (bardzo rzadko!)

## Instalacja lokalna

```bash
# Zainstaluj zależności
npm install

# Uruchom serwer deweloperski
npm run dev
```

Aplikacja będzie dostępna na `http://localhost:5000`

## Deployment na Replit

### Sposób 1: Automatyczny (Replit Publish)

1. Kliknij **Deploy** w Replit
2. Wybierz **Static** deployment
3. Skopiuj wygenerowany URL
4. Skonfiguruj w @BotFather (patrz poniżej)

### Sposób 2: Ręczny

Aplikacja jest już skonfigurowana do hostingu na Replit:
- Vite server serwuje frontend i backend na porcie 5000
- Wszystkie zależności ładowane z CDN (Telegram SDK, Animate.css)
- Brak wymagań node_modules po stronie produkcyjnej

## Konfiguracja Telegram Bot

1. Otwórz [@BotFather](https://t.me/BotFather) w Telegramie

2. Utwórz nowego bota:
```
/newbot
```
Podaj nazwę bota (np. "Encro Verse Bot")

3. Skonfiguruj Menu Button:
```
/mybots
→ Wybierz swojego bota
→ Bot Settings
→ Menu Button
→ Configure menu button
```

4. Wklej URL deploymentu:
```
https://twoj-replit-url.replit.app
```

5. Ustaw nazwę przycisku (np. "Play Game")

6. Gotowe! Użytkownicy mogą teraz uruchomić grę z menu bota

## Struktura projektu

```
client/
├── src/
│   ├── components/
│   │   ├── StarsBalance.tsx      # Wyświetlanie salda
│   │   ├── SpinningWheel.tsx     # Koło fortuny z animacjami
│   │   ├── SpinButton.tsx        # Przycisk "KRĘĆ KOŁEM!"
│   │   ├── RechargeButton.tsx    # Przycisk doładowania
│   │   ├── RewardPopup.tsx       # Popup z nagrodą
│   │   └── Confetti.tsx          # Efekt konfetti
│   ├── lib/
│   │   └── telegram.ts           # Telegram WebApp utilities
│   ├── pages/
│   │   └── game.tsx              # Główna strona gry
│   ├── index.css                 # Style globalne
│   └── App.tsx                   # Root component
├── index.html                    # HTML z Telegram SDK
└── ...
```

## Telegram WebApp API

Aplikacja wykorzystuje:

- `window.Telegram.WebApp.ready()` - inicjalizacja
- `window.Telegram.WebApp.expand()` - pełny ekran
- `HapticFeedback.impactOccurred()` - wibracje
- `showPopup()` - natywne popupy Telegram
- `themeParams` - kolory z motywu Telegram

## Rozwój

### Dodatkowe funkcje do implementacji

- [ ] TON Connect - prawdziwe płatności
- [ ] Daily bonus - bonusy za logowanie
- [ ] Streak system - serie dzienne
- [ ] Progress bar / system poziomów
- [ ] Dźwięki (Web Audio API)
- [ ] Backend API dla bezpiecznego zarządzania saldami
- [ ] Leaderboard - ranking graczy
- [ ] Achievementy

### Debugowanie

W trybie development (poza Telegramem):
- Telegram WebApp API jest symulowane
- Haptic feedback logowany do konsoli
- Popupy zastąpione natywnym `prompt()`

## Technologie

- **Frontend**: React + TypeScript
- **Routing**: Wouter
- **Styling**: Tailwind CSS + custom animations
- **Build**: Vite
- **Backend**: Express.js (dla serwowania plików)
- **Telegram**: Telegram Web App SDK

## Licencja

MIT

## Autor

Encro Verse Team
